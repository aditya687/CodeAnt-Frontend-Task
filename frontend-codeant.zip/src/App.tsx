import { useState } from 'react';
import { Sidebar } from './components/layout/Sidebar';
import { StatsGrid } from './components/stats/StatsGrid';
import { RepositoryList } from './components/repository/RepositoryList';

function App() {
  const [view, setView] = useState<'stats' | 'repos'>('repos');

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <main className="flex-1 p-8">
        <div className="max-w-6xl mx-auto">
          {view === 'stats' ? (
            <div className="mb-8">
              <h1 className="text-2xl font-bold mb-2">AI to Detect & Autofix Bad Code</h1>
              <StatsGrid />
            </div>
          ) : (
            <RepositoryList />
          )}
        </div>
      </main>
    </div>
  );
}

export default App;