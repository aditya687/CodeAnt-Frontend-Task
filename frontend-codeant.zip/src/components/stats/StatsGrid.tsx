import { PieChart } from 'lucide-react';
import { StatsCard } from './StatsCard';

export const StatsGrid = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      <StatsCard
        title="Language Support"
        value="30+"
      />
      <StatsCard
        title="Developers"
        value="10K+"
      />
      <StatsCard
        title="Hours Saved"
        value="100K+"
      />
      <StatsCard
        title="Issues Fixed"
        value="500K+"
        trend={{
          value: "14%",
          label: "This week"
        }}
        icon={<PieChart size={24} />}
      />
    </div>
  );
};