import { ReactNode } from 'react';

interface StatsCardProps {
  title: string;
  value: string;
  subtitle?: string;
  icon?: ReactNode;
  trend?: {
    value: string;
    label: string;
  };
}

export const StatsCard = ({ title, value, subtitle, icon, trend }: StatsCardProps) => {
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-gray-600 font-medium">{title}</h3>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-4xl font-bold">{value}</span>
            {subtitle && <span className="text-gray-500">{subtitle}</span>}
          </div>
          {trend && (
            <div className="mt-2 flex items-center gap-1">
              <span className="text-blue-500">↑ {trend.value}</span>
              <span className="text-gray-500">{trend.label}</span>
            </div>
          )}
        </div>
        {icon && <div className="text-gray-400">{icon}</div>}
      </div>
    </div>
  );
};