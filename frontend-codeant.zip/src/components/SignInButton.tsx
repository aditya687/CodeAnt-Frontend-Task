import { ReactNode } from 'react';

interface SignInButtonProps {
  icon: ReactNode;
  provider: string;
  onClick?: () => void;
}

export const SignInButton = ({ icon, provider, onClick }: SignInButtonProps) => {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-lg
                border border-gray-200 bg-white hover:bg-gray-50 transition-colors"
    >
      {icon}
      <span className="text-gray-900">Sign in with {provider}</span>
    </button>
  );
};