import { ReactNode } from 'react';

interface ButtonProps {
  variant?: 'primary' | 'secondary';
  children: ReactNode;
  icon?: ReactNode;
  onClick?: () => void;
  className?: string;
}

export const Button = ({
  variant = 'secondary',
  children,
  icon,
  onClick,
  className = ''
}: ButtonProps) => {
  return (
    <button
      onClick={onClick}
      className={`
        flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors
        ${variant === 'primary'
          ? 'bg-blue-500 text-white hover:bg-blue-600'
          : 'bg-white text-gray-900 border border-gray-200 hover:bg-gray-50'}
        ${className}
      `}
    >
      {icon}
      {children}
    </button>
  );
};