import { ReactNode } from 'react';

interface ButtonProps {
  variant?: 'primary' | 'secondary';
  children: ReactNode;
  onClick?: () => void;
  className?: string;
}

export const Button = ({ 
  variant = 'secondary', 
  children, 
  onClick,
  className = ''
}: ButtonProps) => {
  return (
    <button
      onClick={onClick}
      className={`
        w-full px-4 py-2 rounded-lg font-medium transition-colors
        ${variant === 'primary' 
          ? 'bg-blue-500 text-white hover:bg-blue-600' 
          : 'bg-white text-gray-900 hover:bg-gray-50'}
        ${className}
      `}
    >
      {children}
    </button>
  );
};