import { ReactNode } from 'react';

interface NavLinkProps {
  icon: ReactNode;
  label: string;
  href: string;
}

export const NavLink = ({ icon, label, href }: NavLinkProps) => {
  return (
    <a 
      href={href}
      className="flex items-center gap-3 px-3 py-2 text-gray-700 hover:bg-gray-50 rounded-lg transition-colors"
    >
      {icon}
      <span>{label}</span>
    </a>
  );
};