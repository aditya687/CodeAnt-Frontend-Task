import { ChevronDown } from 'lucide-react';

interface UserDropdownProps {
  username: string;
}

export const UserDropdown = ({ username }: UserDropdownProps) => {
  return (
    <button className="w-full px-3 py-2 flex items-center justify-between text-gray-700 hover:bg-gray-50 rounded-lg transition-colors">
      <span className="font-medium">{username}</span>
      <ChevronDown size={20} />
    </button>
  );
};