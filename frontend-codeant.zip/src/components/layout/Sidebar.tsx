import { Home, Code, Cloud, HelpCircle, Settings, Phone, LogOut } from 'lucide-react';
import { Logo } from '../Logo';
import { NavLink } from './NavLink';
import { UserDropdown } from './UserDropdown';

export const Sidebar = () => {
  return (
    <div className="w-64 h-screen bg-white border-r border-gray-200 p-4 flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <Logo />
      </div>
      
      <UserDropdown username="UtkarshDhairyaPanwar" />
      
      <nav className="space-y-1 mt-6">
        <NavLink icon={<Home size={20} />} label="Repositories" href="#" />
        <NavLink icon={<Code size={20} />} label="AI Code Review" href="#" />
        <NavLink icon={<Cloud size={20} />} label="Cloud Security" href="#" />
        <NavLink icon={<HelpCircle size={20} />} label="How to Use" href="#" />
        <NavLink icon={<Settings size={20} />} label="Settings" href="#" />
        <NavLink icon={<Phone size={20} />} label="Support" href="#" />
        <NavLink icon={<LogOut size={20} />} label="Logout" href="#" />
      </nav>
    </div>
  );
};