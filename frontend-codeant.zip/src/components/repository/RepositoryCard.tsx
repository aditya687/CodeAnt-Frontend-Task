interface RepositoryCardProps {
  name: string;
  isPublic: boolean;
  language: string;
  size: string;
  updatedAt: string;
}

export const RepositoryCard = ({
  name,
  isPublic,
  language,
  size,
  updatedAt
}: RepositoryCardProps) => {
  return (
    <div className="p-4 bg-white rounded-lg border border-gray-200 hover:border-gray-300 transition-colors">
      <div className="flex justify-between items-start">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-medium text-gray-900">{name}</h3>
            <span className={`px-2 py-1 text-xs rounded-full ${
              isPublic 
                ? 'bg-blue-100 text-blue-800'
                : 'bg-gray-100 text-gray-800'
            }`}>
              {isPublic ? 'Public' : 'Private'}
            </span>
          </div>
          <div className="flex items-center gap-2 mt-1 text-sm text-gray-600">
            <span>{language}</span>
            <span>•</span>
            <span>{size}</span>
            <span>•</span>
            <span>Updated {updatedAt}</span>
          </div>
        </div>
      </div>
    </div>
  );
};