interface Repository {
  name: string;
  isPublic: boolean;
  language: string;
  size: string;
  updatedAt: string;
}

export const RepositoryList = () => {
  const repositories: Repository[] = [
    {
      name: 'design-system',
      isPublic: true,
      language: 'React',
      size: '7320 KB',
      updatedAt: '1 day ago'
    },
    // Add more repositories as needed
  ];

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold">Repositories</h1>
        <div className="flex gap-2">
          <button className="px-4 py-2 rounded-lg border border-gray-200 hover:bg-gray-50">
            Refresh All
          </button>
          <button className="px-4 py-2 rounded-lg bg-blue-500 text-white hover:bg-blue-600">
            Add Repository
          </button>
        </div>
      </div>
      
      <input
        type="text"
        placeholder="Search Repositories"
        className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
      />
      
      <div className="space-y-2">
        {repositories.map((repo) => (
          <div key={repo.name} className="p-4 rounded-lg border border-gray-200">
            <div className="flex justify-between items-center">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-medium">{repo.name}</span>
                  <span className="px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800">
                    {repo.isPublic ? 'Public' : 'Private'}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <span>{repo.language}</span>
                  <span>•</span>
                  <span>{repo.size}</span>
                  <span>•</span>
                  <span>Updated {repo.updatedAt}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};